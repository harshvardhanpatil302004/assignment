import { LightningElement, wire } from 'lwc';

import { CurrentPageReference } from 'lightning/navigation';

import getContacts
    from '@salesforce/apex/ContactController.getContacts';

import {
    registerListener,
    unregisterAllListeners
} from 'c/pubsub';


export default class LwcLocalDevelopmentQuestion2 extends LightningElement {

    @wire(CurrentPageReference)
    pageRef;


    accountId = null;

    contacts = [];

    showNoAccount = true;


    connectedCallback() {

        registerListener(
            'accountselected',
            this.handleAccountSelected,
            this
        );
    }


    disconnectedCallback() {

        unregisterAllListeners(this);
    }


    // Receive Account Id from Q1
    handleAccountSelected(accountId) {

        this.accountId = accountId;

        this.getContactRecords();
    }


    // Check whether Contacts are available
    get hasContacts() {

        return this.contacts.length > 0;
    }


    // Show message when Account is selected but no Contacts exist
    get showNoContacts() {

        return (
            !this.showNoAccount &&
            this.contacts.length === 0
        );
    }


    // Get Contacts for selected Account
    getContactRecords() {

        if (!this.accountId) {

            this.contacts = [];

            this.showNoAccount = true;

            return;
        }


        this.showNoAccount = false;


        getContacts({
            accountId: this.accountId
        })

        .then(result => {

            this.contacts = result.map(contact => {

                return {
                    ...contact,

                    mailingAddress: this.formatAddress(contact)
                };

            });

        })

        .catch(error => {

            console.error(
                'Error retrieving Contacts:',
                error
            );

            this.contacts = [];

        });
    }


    // Format Mailing Address
    formatAddress(contact) {

        return [
            contact.MailingStreet,
            contact.MailingCity,
            contact.MailingState,
            contact.MailingPostalCode,
            contact.MailingCountry
        ]
        .filter(value => value)
        .join(', ');
    }

}