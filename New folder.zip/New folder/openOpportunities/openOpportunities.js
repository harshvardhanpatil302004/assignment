import { LightningElement, api, wire } from 'lwc';

import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import getOpenOpportunities
    from '@salesforce/apex/AccountSearchController.getOpenOpportunities';

import createOpportunity
    from '@salesforce/apex/AccountSearchController.createOpportunity';

import OPPORTUNITY_CREATED_SUCCESS
    from '@salesforce/label/c.Opportunity_Created_Success';

import OPPORTUNITY_VALIDATION_ERROR
    from '@salesforce/label/c.Opportunity_Validation_Error';

import { refreshApex } from '@salesforce/apex';


export default class OpenOpportunities extends NavigationMixin(LightningElement) {

    @api accountId;

    opportunities = [];

    isLoading = true;

    showCreateForm = false;

    isCreating = false;

    opportunityName = '';

    amount = '';

    stageName = '';

    closeDate = '';

    wiredOpportunityResult;


    // Stage options
    stageOptions = [
        {
            label: 'Prospecting',
            value: 'Prospecting'
        },
        {
            label: 'Qualification',
            value: 'Qualification'
        },
        {
            label: 'Needs Analysis',
            value: 'Needs Analysis'
        },
        {
            label: 'Value Proposition',
            value: 'Value Proposition'
        },
        {
            label: 'Id. Decision Makers',
            value: 'Id. Decision Makers'
        },
        {
            label: 'Perception Analysis',
            value: 'Perception Analysis'
        },
        {
            label: 'Proposal/Price Quote',
            value: 'Proposal/Price Quote'
        },
        {
            label: 'Negotiation/Review',
            value: 'Negotiation/Review'
        }
    ];


    // ---------------------------------------------------------
    // Get Open Opportunities
    // ---------------------------------------------------------

    @wire(getOpenOpportunities, { accountId: '$accountId' })
    wiredOpportunities(result) {

        this.wiredOpportunityResult = result;

        this.isLoading = false;

        const { data, error } = result;

        if (data) {

            this.opportunities = data;

        } else if (error) {

            this.opportunities = [];

            console.error(
                'Error retrieving Opportunities:',
                error
            );
        }
    }


    // ---------------------------------------------------------
    // Check whether opportunities are available
    // ---------------------------------------------------------

    get hasOpportunities() {

        return this.opportunities.length > 0;
    }


    // ---------------------------------------------------------
    // Display message when no opportunities exist
    // ---------------------------------------------------------

    get showNoOpportunities() {

        return !this.isLoading &&
               this.opportunities.length === 0;
    }


    // ---------------------------------------------------------
    // Open Create Opportunity Form
    // ---------------------------------------------------------

    handleCreateOpportunity() {

        this.showCreateForm = true;

        this.resetForm();
    }


    // ---------------------------------------------------------
    // Close Create Opportunity Form
    // ---------------------------------------------------------

    handleCancel() {

        this.showCreateForm = false;

        this.resetForm();
    }


    // ---------------------------------------------------------
    // Handle Opportunity Name
    // ---------------------------------------------------------

    handleOpportunityNameChange(event) {

        this.opportunityName = event.target.value;
    }


    // ---------------------------------------------------------
    // Handle Amount
    // ---------------------------------------------------------

    handleAmountChange(event) {

        this.amount = event.target.value;
    }


    // ---------------------------------------------------------
    // Handle Stage
    // ---------------------------------------------------------

    handleStageChange(event) {

        this.stageName = event.detail.value;
    }


    // ---------------------------------------------------------
    // Handle Close Date
    // ---------------------------------------------------------

    handleCloseDateChange(event) {

        this.closeDate = event.target.value;
    }


    // ---------------------------------------------------------
    // Create Opportunity
    // ---------------------------------------------------------

    handleSaveOpportunity() {

        // Basic validation

        if (!this.opportunityName ||
            !this.opportunityName.trim()) {

            this.showErrorToast(
                'Error',
                'Please enter an Opportunity Name.'
            );

            return;
        }


        // Assignment validation:
        // Amount must be greater than 0

        if (!this.amount || Number(this.amount) <= 0) {

            this.showErrorToast(
                'Validation Error',
                OPPORTUNITY_VALIDATION_ERROR
            );

            return;
        }


        if (!this.stageName) {

            this.showErrorToast(
                'Error',
                'Please select a Stage.'
            );

            return;
        }


        if (!this.closeDate) {

            this.showErrorToast(
                'Error',
                'Please select a Close Date.'
            );

            return;
        }


        if (!this.accountId) {

            this.showErrorToast(
                'Error',
                'Please select an Account first.'
            );

            return;
        }


        this.isCreating = true;


        createOpportunity({
            opportunityName: this.opportunityName.trim(),
            accountId: this.accountId,
            amount: Number(this.amount),
            stageName: this.stageName,
            closeDate: this.closeDate
        })

        .then(result => {

            // Hide form
            this.showCreateForm = false;

            // Reset form
            this.resetForm();


            // Refresh Opportunity table
            return refreshApex(this.wiredOpportunityResult)

                .then(() => {

                    // Show success toast
                    this.showSuccessToast(
                        result.Id,
                        result.Name
                    );

                });

        })

        .catch(error => {

            console.error(
                'Error creating Opportunity:',
                error
            );


            let message = 'An error occurred while creating the Opportunity.';


            if (
                error &&
                error.body &&
                error.body.message
            ) {

                message = error.body.message;
            }


            this.showErrorToast(
                'Error',
                message
            );

        })

        .finally(() => {

            this.isCreating = false;

        });
    }


    // ---------------------------------------------------------
    // Success Toast with Opportunity Link
    // ---------------------------------------------------------

    showSuccessToast(recordId, recordName) {

        this.dispatchEvent(
            new ShowToastEvent({

                title: 'Success',

                message:
                    OPPORTUNITY_CREATED_SUCCESS +
                    ' {0}',

                messageData: [
                    {
                        url:
                            `/lightning/r/Opportunity/${recordId}/view`,

                        label: 'View Opportunity'
                    }
                ],

                variant: 'success'
            })
        );
    }


    // ---------------------------------------------------------
    // Error Toast
    // ---------------------------------------------------------

    showErrorToast(title, message) {

        this.dispatchEvent(
            new ShowToastEvent({

                title: title,

                message: message,

                variant: 'error'
            })
        );
    }


    // ---------------------------------------------------------
    // Reset Form
    // ---------------------------------------------------------

    resetForm() {

        this.opportunityName = '';

        this.amount = '';

        this.stageName = '';

        this.closeDate = '';
    }


    // ---------------------------------------------------------
    // Opportunity Name Click
    // Navigate to Opportunity in Separate Tab
    // ---------------------------------------------------------

    handleOpportunityClick(event) {

        event.preventDefault();

        const opportunityId =
            event.currentTarget.dataset.id;


        this[NavigationMixin.GenerateUrl]({

            type: 'standard__recordPage',

            attributes: {

                recordId: opportunityId,

                objectApiName: 'Opportunity',

                actionName: 'view'

            }

        })

        .then(url => {

            window.open(url, '_blank');

        });
    }


    // ---------------------------------------------------------
    // Account Name Click
    // Navigate to Account Record
    // ---------------------------------------------------------

    handleAccountClick(event) {

        event.preventDefault();

        const accountId =
            event.currentTarget.dataset.id;


        this[NavigationMixin.Navigate]({

            type: 'standard__recordPage',

            attributes: {

                recordId: accountId,

                objectApiName: 'Account',

                actionName: 'view'

            }

        });
    }

}