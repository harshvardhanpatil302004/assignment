import searchAccounts from '@salesforce/apex/AccountSearchController.searchAccounts';
import { LightningElement, wire } from 'lwc';

import { CurrentPageReference } from 'lightning/navigation';



import { fireEvent } from 'c/pubsub';


export default class LwcLocalDevelopmentQuestion1 extends LightningElement {

     @wire(CurrentPageReference)
    pageRef;
    searchKey = '';

    accounts = [];

    accountOptions = [];

    selectedAccountId = '';

    selectedAccount = null;

    selectedOpportunityName = '';

    showDropdown = false;

    noAccountsFound = false;

    isLoading = false;


    // Handle changes in the search input
    handleSearchKeyChange(event) {

        this.searchKey = event.target.value;

        this.showDropdown = false;

        this.noAccountsFound = false;

        this.accounts = [];

        this.accountOptions = [];

        this.selectedAccountId = '';

        this.selectedAccount = null;

        this.selectedOpportunityName = '';
    }


    // Search Accounts
    handleSearch() {

        this.showDropdown = false;

        this.noAccountsFound = false;

        this.accounts = [];

        this.accountOptions = [];

        this.selectedAccountId = '';

        this.selectedAccount = null;

        this.selectedOpportunityName = '';


        if (!this.searchKey || !this.searchKey.trim()) {

            this.noAccountsFound = true;

            return;
        }


        this.isLoading = true;


        // Imperative Apex Call
        searchAccounts({
            searchKey: this.searchKey
        })

        .then(result => {

            this.accounts = result;


            if (this.accounts.length > 0) {

                // Convert Accounts into combobox options
                this.accountOptions = this.accounts.map(account => {

                    return {
                        label: account.Name,
                        value: account.Id
                    };

                });

                this.showDropdown = true;

            } else {

                this.noAccountsFound = true;

            }

        })

        .catch(error => {

            console.error('Error searching Accounts:', error);

            this.noAccountsFound = true;

        })

        .finally(() => {

            this.isLoading = false;

        });
    }


    // Handle Account Selection
  handleAccountSelection(event) {

    this.selectedAccountId = event.detail.value;

    this.selectedAccount = this.accounts.find(
        account => account.Id === this.selectedAccountId
    );

    this.selectedOpportunityName = '';


    // Publish selected Account Id
    fireEvent(
        this.pageRef,
        'accountselected',
        this.selectedAccountId
    );
}


    // Handle Opportunity Selection from Child
    handleOpportunitySelection(event) {

        this.selectedOpportunityName = event.detail;
    }

}