import { LightningElement, api, wire } from 'lwc';
import getRelatedRecords
    from '@salesforce/apex/AccountRelatedRecordsController.getRelatedRecords';
export default class AccountRelatedRecords extends LightningElement {
    @api recordId;
    relatedRecords;
    errorMessage;
    isLoading = true;

   @wire(getRelatedRecords, { accountId: '$recordId' })
wiredRelatedRecords({ data, error }) {
    this.isLoading = false;
    if (data) {
        this.relatedRecords = data;
        this.errorMessage = undefined;
    } else if (error) {
        this.relatedRecords = undefined;
        
        // Safely extract the message even if error.body is missing
        if (error.body && error.body.message) {
            this.errorMessage = error.body.message;
        } else if (typeof error.message === 'string') {
            this.errorMessage = error.message;
        } else {
            this.errorMessage = JSON.stringify(error);
        }
    }
}}
