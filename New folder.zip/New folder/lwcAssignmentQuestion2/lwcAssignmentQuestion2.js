import { LightningElement } from 'lwc';
import getTopOpportunities from '@salesforce/apex/QuarterlyTopOpportunitiesController.getTopOpportunities';

export default class QuarterlyTopOpportunities extends LightningElement {
    opportunities = [];
    errorMessage;
    isLoading = false;
    hasSearched = false;

    async handleFetchOpportunities() {
        this.isLoading = true;
        this.hasSearched = true;
        this.errorMessage = undefined;
        this.opportunities = [];

        console.log('everything before try working');
        try {
            console.log('everything before fetch');
            // FIX: Changed from getQuarterlyTopOpportunities() to getTopOpportunities()
            this.opportunities = await getTopOpportunities(); 
            console.log('everything after fetch');
        } catch (error) {
            console.log('this is error happin here');
            this.errorMessage = error.body?.message || 'Unable to retrieve quarterly opportunities.';
        } finally {
            this.isLoading = false;
        }
    }

    get hasOpportunities() {
        return this.opportunities.length > 0;
    }

    get showNoRecordsMessage() {
        return this.hasSearched && !this.isLoading && !this.errorMessage && this.opportunities.length === 0;
    }
}
