/**
 * A basic pub-sub mechanism for sibling component communication
 *
 * This module is used to communicate between components
 * that are not in the same DOM hierarchy.
 */

const events = {};


/**
 * Compare two PageReference objects.
 *
 * Pub/Sub events are restricted to components
 * that are on the same page.
 */
const samePageRef = (pageRef1, pageRef2) => {

    const obj1 = pageRef1.attributes;
    const obj2 = pageRef2.attributes;

    return Object.keys(obj1)
        .concat(Object.keys(obj2))
        .every(key => {
            return obj1[key] === obj2[key];
        });
};


/**
 * Register a listener for an event.
 *
 * @param {string} eventName
 * @param {function} callback
 * @param {object} thisArg
 */
const registerListener = (eventName, callback, thisArg) => {

    // Subscriber must have CurrentPageReference
    if (!thisArg.pageRef) {

        throw new Error(
            'pubsub listeners need a "@wire(CurrentPageReference) pageRef" property'
        );
    }


    // Create event array if it does not exist
    if (!events[eventName]) {

        events[eventName] = [];
    }


    // Prevent duplicate listeners
    const duplicate = events[eventName].find(listener => {

        return (
            listener.callback === callback &&
            listener.thisArg === thisArg
        );

    });


    if (!duplicate) {

        events[eventName].push({
            callback,
            thisArg
        });

    }
};


/**
 * Unregister a particular listener.
 *
 * @param {string} eventName
 * @param {function} callback
 * @param {object} thisArg
 */
const unregisterListener = (eventName, callback, thisArg) => {

    if (events[eventName]) {

        events[eventName] = events[eventName].filter(
            listener =>
                listener.callback !== callback ||
                listener.thisArg !== thisArg
        );

    }
};


/**
 * Unregister all listeners belonging to a component.
 *
 * @param {object} thisArg
 */
const unregisterAllListeners = thisArg => {

    Object.keys(events).forEach(eventName => {

        events[eventName] = events[eventName].filter(
            listener => listener.thisArg !== thisArg
        );

    });
};


/**
 * Fire an event.
 *
 * @param {object} pageRef
 * @param {string} eventName
 * @param {*} payload
 */
const fireEvent = (pageRef, eventName, payload) => {

    if (events[eventName]) {

        const listeners = events[eventName];

        listeners.forEach(listener => {

            if (
                samePageRef(
                    pageRef,
                    listener.thisArg.pageRef
                )
            ) {

                try {

                    listener.callback.call(
                        listener.thisArg,
                        payload
                    );

                } catch (error) {

                    // Fail silently
                }

            }

        });

    }
};


export {
    registerListener,
    unregisterListener,
    unregisterAllListeners,
    fireEvent
};